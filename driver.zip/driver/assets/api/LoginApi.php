<?php
session_start();

$BusNumber=$sql="";
if (isset($_GET["BusNumber"]) && isset($_GET["DriverMobile"])) {
    include('../Database/DBMySql.php');$db=new DBMySql;
    
    $BusNumber =  $_GET["BusNumber"];
    $DriverMobile =  $_GET["DriverMobile"];

    
    $sql="select count(*) from `buses` where `BusNumber` ='".$BusNumber."' and `DriverMobile` ='".$DriverMobile."';";
   
    if( $db->ScalerQuery($sql)=="1")
    {
        $sql="select * from `buses` where `BusNumber` ='".$BusNumber."' and `DriverMobile` ='".$DriverMobile."';";
        $row=$db->GetSingleRow($sql);
       
        echo json_encode($row);
       return;
    }
    else{ 

        return "aaa";
       
    }
}else{
    return "bbb";
    
}
echo json_encode($Response);
?>