<?php
session_start();
include_once('../Database/DBMySql.php');$db=new DBMySql;
//$PostData =json_decode(file_get_contents("php://input"));
//echo json_encode($PostData);return;

$Longitude=$_GET["Longitude"];
$Latitude=$_GET["Latitude"];
$BID=$_GET["BID"];


$db->NonQuery("delete from locations where BID=".$BID);
$sql = "INSERT INTO `locations`( `Longitude`,`Latitude`,`LastUpdateTime`,`BID`) VALUES ('".$Longitude."','".$Latitude."',NOW(),".$BID.")";

if($db->NonQuery($sql))
{
    $Response["Status"]='Success';
    
}
else{
    $Response["Status"]='Error';
    $Response["Message"]=$sql;
}

echo json_encode($Response);

?>