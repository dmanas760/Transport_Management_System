﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Bus_Pass_Mgt_Asp.Models
{
    public class Bus
    {
        [Key]
        public int BID { get; set; }
        [Display (Name ="Bus Number")]
        [Required]
        public string BusNumber { get; set; } = "XXXXXXXXXX";
        [Display(Name = "Visiting Areas")]
        [Required]
        public string VisitingAreas { get; set; } = "";
        [Display(Name = "Driver Name")]
        [Required]
        public string DriverName { get; set; }
        [Display(Name = "Driver Mobile")]
        [Required]
        public string DriverMobile { get; set; }


        [NotMapped]
        public string MapLink { get; set; }
    }
}
