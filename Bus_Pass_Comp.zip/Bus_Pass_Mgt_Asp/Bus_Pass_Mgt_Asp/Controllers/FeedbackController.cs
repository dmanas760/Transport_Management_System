﻿using Bus_Pass_Mgt_Asp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bus_Pass_Mgt_Asp.Controllers
{
    public class FeedbackController : Controller
    {
        private readonly MyDBContext db;

        public FeedbackController(MyDBContext context)
        {
            db = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Submit(Feedback feedback)
        {
            if (ModelState.IsValid)
            {
                // Insert data into the database or perform other actions
                // using MySQL connection and queries
                db.Feedback.Add(feedback);
                db.SaveChanges();
                // Redirect to a confirmation page or display a success message
                return Redirect("/");
            }

            return View("Index", feedback);
        }

        public IActionResult FeedbackBoard()
        {
            var feedbackList = db.Feedback.ToList();
            return View(feedbackList);
        }
        public IActionResult Confirmation()
        {
            return View();
        }
        [HttpPost]
        public IActionResult MarkAsSolved(int id)
        {
            var feedback = db.Feedback.Find(id);
            if (feedback != null)
            {
                feedback.IsSolved = true;
                db.SaveChanges();
            }
            return Ok();
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            var feedback = db.Feedback.Find(id);
            if (feedback != null)
            {
                db.Feedback.Remove(feedback);
                db.SaveChanges();
            }
            return Ok();
        }
    }
}
